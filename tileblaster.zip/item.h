#ifndef _ITEM_H_
#define _ITEM_H_

#define Item void *
#define exch(a, b) {Item p = a; a = b; b = p;}

#endif
